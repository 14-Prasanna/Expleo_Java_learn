package array_hand_on;

import java.util.Scanner;

public class MaxMin {
	
	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        System.out.println("Enter the number of elements:");
	        int n = sc.nextInt();

	        int arr[] = new int[n];

	        System.out.println("Enter array values:");
	        for(int i = 0; i < n; i++) {
	            arr[i] = sc.nextInt();
	        }
	        
	        int max = Integer.MIN_VALUE;
	        int min = Integer.MAX_VALUE;
	        
	       
	        for(int i=0;i<n;i++) {
	        	if(arr[i] > max) {
	        		max = arr[i];
	        	}
	        	if(arr[i] < min) {
	        		min = arr[i];
	        	}
	        }

	        System.out.println("The min and max value in the array");
	        System.out.println("The max: " + (max) + " The min: " +(min) );
	    }
	
}
